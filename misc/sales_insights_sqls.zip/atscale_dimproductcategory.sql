INSERT INTO atscale.dimproductcategory (productcategorykey, productcategoryalternatekey, productcategoryname) VALUES (1, 1, 'Bikes');
INSERT INTO atscale.dimproductcategory (productcategorykey, productcategoryalternatekey, productcategoryname) VALUES (2, 2, 'Components');
INSERT INTO atscale.dimproductcategory (productcategorykey, productcategoryalternatekey, productcategoryname) VALUES (3, 3, 'Clothing');
INSERT INTO atscale.dimproductcategory (productcategorykey, productcategoryalternatekey, productcategoryname) VALUES (4, 4, 'Accessories');
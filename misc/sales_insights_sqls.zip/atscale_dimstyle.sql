INSERT INTO atscale.dimstyle (stylekey, stylename) VALUES ('U', 'Unisex');
INSERT INTO atscale.dimstyle (stylekey, stylename) VALUES ('W', 'Womens');
INSERT INTO atscale.dimstyle (stylekey, stylename) VALUES ('M', 'Mens');
INSERT INTO atscale.dimstyle (stylekey, stylename) VALUES ('UN', 'Not Applicable');
INSERT INTO atscale.dim_geo_country (country) VALUES ('France');
INSERT INTO atscale.dim_geo_country (country) VALUES ('United States');
INSERT INTO atscale.dim_geo_country (country) VALUES ('Australia');
INSERT INTO atscale.dim_geo_country (country) VALUES ('Canada');
INSERT INTO atscale.dim_geo_country (country) VALUES ('Germany');
INSERT INTO atscale.dim_geo_country (country) VALUES ('United Kingdom');
INSERT INTO atscale.dimgender (genderkey, gendername) VALUES ('M', 'Male');
INSERT INTO atscale.dimgender (genderkey, gendername) VALUES ('F', 'Female');
INSERT INTO atscale.dimgender (genderkey, gendername) VALUES ('U', 'Unisex');